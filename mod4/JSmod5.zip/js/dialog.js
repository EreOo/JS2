function getId(first){
 var dialog = document.getElementById(first);
 return dialog;
} 

function log(text,comment){
  document.getElementById("log").innerHTML = text+"<br>";
} 